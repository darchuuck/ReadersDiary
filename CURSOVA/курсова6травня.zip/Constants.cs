﻿namespace CURSOVA
{
    public class Constants
    {
        public static string Address = "https://hapi-books.p.rapidapi.com";
        public static string ApiKey = "739df69bb7mshf323814fcf13156p14478ajsn26867caa828b";
        public static string ApiHost = "hapi-books.p.rapidapi.com";
    }
    
}
