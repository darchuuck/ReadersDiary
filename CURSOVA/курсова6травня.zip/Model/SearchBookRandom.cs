﻿namespace ReadingDiary.Model
{
    public class SearchBookRandom
    {
        public string Name { get; set; }
        public string Cover { get; set; }
        public string Url { get; set; }
    }
}
