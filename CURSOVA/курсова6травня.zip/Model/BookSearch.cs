﻿namespace CURSOVA.Model
{

    public class BookSearch
    {
       
        public string Name { get; set; }
        public string Cover { get; set; }
        public string Url { get; set; }
        public string[] Authors { get; set; }
        public double Rating { get; set; }
        public int Year { get; set; }
    }

}
